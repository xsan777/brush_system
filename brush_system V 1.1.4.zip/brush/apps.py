from django.apps import AppConfig


class BrushConfig(AppConfig):
    name = 'brush'
